<style> 
body {
background: url(http://37.media.tumblr.com/tumblr_lusitdffhf1qj5tnlo1_r1_500.gif);
background-size: 2000px 1000px;
background-repeat:repeat;
padding-top: 40px;
}



   <h1 style="color:Tomato;">To Al-Istiqama Group
    welcome you to its Official website</h1>
      
  <button>
    Hello
  </button>
  <h1 style="color:Tomato;">Old Website</h1>
  
  <a href="http://stqgroup.com.sa/" target="blank">
    Link to stqgroup.com.sa 
  </a>
  
  

   <style>
    p {
      font-family: Arial;
      margin-top: 10;
      margin-bottom: 20;
    }
  
    .video-stats {
      font-size: 14px;
      color: rgb(96, 96, 96);
      margin-bottom: 20px;
    }
  

.video-title {
      font-weight: bold;
      font-size: 18px;
      width: 280px;
      line-height: 24px;
      margin-bottom: 5px;
    }
  
	
    .video-author {
      font-size: 14px;
      color: rgb(96, 96, 96);
      margin-bottom: 20px;
    }
  
    .video-description {
      font-size: 14px;
      color: rgb(96, 96, 96);
      width: 280px;
      line-height: 22px;
      margin-bottom: 100px;
    }
  
    .apple-text {
      margin-bottom: 50px;
      font-size: 14px;
      background-color: rgb(227, 65, 64);
      color: white;
      text-align: center;
      padding-top: 18px;
      padding-bottom: 18px;
    }
  
    .span-example {
      color: red;
    }
  
    .span-example:hover {
      text-decoration: underline;
    }
  
    .shop-link {
      cursor: pointer;
    }
  
    .shop-link:hover {
      text-decoration: underline;
    }
  </style>
  
  <p class="video-title">
  
    <h1 style="color:Tomato;">New Website SOON!</h1>
    
  </p>
  
  <p class="video-stats">
    3.4M views &#183; 1 months ago
  </p>
  <h1 style="color:Tomato;">STQ Group.. The Straightforward Group&#10003;</h1>
  
  
  <p class="video-author">
     
  </p>
  
           
  <p class="video-description">
    
  
  <p class="apple-text">
    We are the Esteqama Group for 
    implementing, supplying
    and installing all systems for 
    professional theatrical lighting 
    and audio equipment, 
    conference halls and studios. 
    Supplying and installing all 
    types of chairs, curtains, 
    decorations and insulation for
     theaters, conference halls 
     and studios. Adding the 
    ability to display 3D movies
     Dimension Cinema with stereoscopic
      effects in the image 
    and sound in theaters. Adding 
    a meeting system equipped with
     Audio Video audio and visual
     devices. Displaying the results
      of the secret ballot in seconds.
       IR Assistive Listening 
     System for conferences works 
     with infrared rays up to 4 languages
      ​​and their multiples. 
     Using the theater as a training and
      education hall and raising the 
      level of leadership 
     through smart boards, giant screens
     , 3D projectors, distinctive audio 
     conferences, and 
     equipping and installing video 
     conference systems. Converting 
     the show in large theaters 
     to a cinematic display system. 
     Making all designs and engineering 
     specifications for all
      works. There is a team of specialized 
      and highly experienced engineers in 
      this field. 
      Supplying and installing surveillance
       cameras, closed 
    circuit television (CCTV), security and 
    safety devices and the security system.!

   All rights reserved - Al-Istiqama for Theater and Hall Equipment. 
To contact us:Al-Istiqama Group for Theater and Hall Equipment

Kingdom of Saudi Arabia
Qassim - Unaizah - P.O. Box: 1502 - Postal Code: 51911
Phone: +9660000000
Fax: +966000000000
Email: ooooooooooooo <span class="Shop now"> &#62;
NEW WEBSITE <strong> UNDER </strong> CONTRUCTION <u> New website </u> opening soon. <span class="span-example">  



    
      
    
<div class="col-md-4">
<h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">For your business to succeed, you need experienced people to implement it.. </font></font><br><span class="id-color"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">STQ Group.. The Straightforward Group</font></font></span></h5>
</div>
<div class="col-md-4">
<div class="col-md-4"><a class="btn btn-extra-large btn-primary" href="/9/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">View our latest projects</font></font></a></div>

 <iframe width="980" height="400" src="https://www.youtube-nocookie.com/embed/3QArAxmiR6k?si=-dyyi-OujJ-D1p4i" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe><iframe width="980" height="400" src="https://www.youtube.com/embed/6ar3kqoESfo?si=ng1P49hjYkWUkULo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe><iframe width="980" height="400" src="https://www.youtube.com/embed/nR77DVOdfmA?si=F4s9e0vBOvWY6fbY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe><iframe width="980" height="400" src="https://www.youtube.com/embed/JQ35tdRyWX0?si=D9w-cLsWv6pb0ih8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

 

 
 

	
	<a href="/"><li><a href="http://stqgroup.com.sa/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Home</font></font></a></li>

          
    
        <li class="">
            <a href="/#welcome">
              <span class="icon-info"></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  About us             </font></font></a>
                        <ul class="dropdown-menu">
                
        
            
        <li class="">
            <a href="/pages/كلمة-المدير-العام"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Director General's speech             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/نشأة-المجموعة"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                The origin of the group             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/الرؤية-والرسالة"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Vision and Mission             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/أنشطة المجموعة"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Group activities             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/طلب مشروع"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Project request             </font></font></a>
            
        </li>
            </ul>

        </li>
        <li class="">
            <a href="/#services">
              <span class="icon-list"></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  Services and Activities             </font></font></a>
                        <ul class="dropdown-menu">
            
        <li class="">
            <a href="/pages/تجهيزات-المسارح"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Theater equipment             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/الكراسي"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Theater chairs             </font></font></a>
                        <ul class="dropdown-menu">
            
        <li class="">
            <a href="http://seats.stqgroup.com.sa/CatPage/MyCatPage?cat=turkey1" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Chairs Catalog 1             </font></font></a>
            
        </li>
            </ul>

        </li>
        <li class="">
            <a href="/pages/القاعات"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Meeting and conference rooms             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/تجهيزات-المؤتمرات"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Conference Equipment             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/الأمن-والسلامة"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Security and Safety             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/الإنتاج-الإعلامي"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Media production             </font></font></a>
            
        </li>
            </ul>

        </li>
        <li class="">
            <a href="/9/">
              <span class="icon-cogs"></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  Projects             </font></font></a>
                        <ul class="dropdown-menu">
            
        <li class="">
            <a href="/9/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Projects review             </font></font></a>
            
        </li>
        <li class="">
            <a href="/2/12/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Project Visuals             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/المشاريع-المنتهية"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                List of completed projects             </font></font></a>
            
        </li>
            </ul>

        </li>
        <li class="">
            <a href="/10/4">
              <span class="icon-edit"></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  Group News             </font></font></a>
            
        </li>
        <li class="">
            <a href="/pages/اتصل-بنا">
              <span class="icon-phone"></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  Contact us             </font></font></a>
            
        </li>



<!-- header close -->
        <!-- ngView:  --><div ng-view="" class="ng-scope"><!-- ngIf: isHome --><div ng-controller="HomeController" ng-if="isHome" class="ng-scope">
    <!-- slider -->
    <div class="fullwidthbanner-container" style="overflow: visible;">
        <div id="revolution-slider" flexslider-main="" class="revslider-initialised tp-simpleresponsive" style="height: 432px;">
            <ul style="display: block; overflow: hidden; width: 100%; height: 100%; max-height: none;">
                <li data-transition="fade" data-slotamount="20" data-masterspeed="300" data-thumb="/uploads/general/images-slider/thumbs/thumb1.jpg" style="width: 100%; height: 100%; overflow: hidden; visibility: visible; left: 0px; top: 0px; z-index: 18; opacity: 1;">

                    <div class="slotholder"><img ng-src="/uploads/general/images-slider/wide-thetre2.jpg" alt="" class="defaultimg" style="height: 432px; width: 1175.76px; position: relative; left: -127.5px; top: 0px; opacity: 0;" src="/uploads/general/images-slider/wide-thetre2.jpg"></div>

                    <div class="tp-caption lft start" data-x="210" data-y="195" data-speed="500" data-start="500" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 201.469px; top: -146px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/stq.png" alt="" src="/uploads/general/images-slider/stq.png" style="width: 479.688px; height: 86.4px;">
                    </div>


                    <div class="caption large_text lfr tp-caption start" data-x="210" data-y="270" data-speed="850" data-start="1250" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 981px; top: 259.188px; visibility: visible;">
                        <a href="/pages/القاعات"><img ng-src="/uploads/general/images-slider/stq2.png" alt="" src="/uploads/general/images-slider/stq2.png" style="width: 479.688px; height: 86.4px;"></a>
                    </div>

                </li>
				<li data-transition="fade" data-slotamount="20" data-masterspeed="300" data-thumb="/uploads/general/images-slider/thumbs/thumb1.jpg" style="width: 100%; height: 100%; overflow: hidden; visibility: visible; left: 0px; top: 0px; z-index: 18; opacity: 1;">

                    <div class="slotholder"><img ng-src="/uploads/general/images-slider/wide-thetre.jpg" alt="" class="defaultimg" style="height: 432px; width: 1175.76px; position: relative; left: -127.5px; top: 0px; opacity: 0;" src="/uploads/general/images-slider/wide-thetre.jpg"></div>

                    <div class="tp-caption lft start" data-x="210" data-y="195" data-speed="0" data-start="0" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 201.469px; top: -146px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/stq.png" alt="" src="/uploads/general/images-slider/stq.png" style="width: 479.688px; height: 86.4px;">
                    </div>


                    <div class="caption large_text lfr tp-caption start" data-x="210" data-y="270" data-speed="0" data-start="0" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 981px; top: 259.188px; visibility: visible;">
                        <a href="/pages/القاعات"><img ng-src="/uploads/general/images-slider/stq2.png" alt="" src="/uploads/general/images-slider/stq2.png" style="width: 479.688px; height: 86.4px;"></a>
                    </div>

                </li>
                <li data-transition="fade" data-slotamount="20" data-masterspeed="300" data-thumb="/uploads/general/images-slider/thumbs/thumb1.jpg" style="width: 100%; height: 100%; overflow: hidden; visibility: visible; left: 0px; top: 0px; z-index: 18; opacity: 1;">
                    <!--  BACKGROUND IMAGE -->
                    <div class="slotholder"><img ng-src="/uploads/general/images-slider/wide4.jpg" alt="" class="defaultimg" style="height: 432px; width: 1175.76px; position: relative; left: -127.5px; top: 0px; opacity: 0;" src="/uploads/general/images-slider/wide4.jpg"></div>
                    <!-- THE CAPTIONS IN THIS SLIDE -->
                    <div class="tp-caption lft start" data-x="290" data-y="195" data-speed="500" data-start="500" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 278.219px; top: -146px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s510.png" alt="" src="/uploads/general/images-slider/s510.png" style="width: 345.375px; height: 86.4px;">
                    </div>
                    <div class="caption large_text lfl tp-caption start" data-x="850" data-y="125" data-speed="450" data-start="800" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: -323px; top: 120px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s51.png" alt="" src="/uploads/general/images-slider/s51.png" style="width: 262.869px; height: 345.6px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="650" data-y="75" data-speed="300" data-start="1000" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 623.594px; top: -244px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s52.png" alt="" src="/uploads/general/images-slider/s52.png" style="width: 243.681px; height: 184.32px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="500" data-y="60" data-speed="300" data-start="1100" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 479.688px; top: -181px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s53.png" alt="" src="/uploads/general/images-slider/s53.png" style="width: 104.572px; height: 120.96px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="320" data-y="60" data-speed="300" data-start="1200" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 307px; top: -181px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s54.png" alt="" src="/uploads/general/images-slider/s54.png" style="width: 107.45px; height: 120.96px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="60" data-y="75" data-speed="300" data-start="1300" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 57.5625px; top: -251px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s55.png" alt="" src="/uploads/general/images-slider/s55.png" style="width: 216.819px; height: 191.04px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="-160" data-y="125" data-speed="300" data-start="1400" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: -153.5px; top: -406px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s56.png" alt="" src="/uploads/general/images-slider/s56.png" style="width: 247.519px; height: 345.6px;">
                    </div>
                    <div class="caption large_text sfb tp-caption start" data-x="150" data-y="310" data-speed="300" data-start="1500" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 143.906px; top: 347.594px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s57.png" alt="" src="/uploads/general/images-slider/s57.png" style="width: 149.662px; height: 179.52px;">
                    </div>
                    <div class="caption large_text sfb tp-caption start" data-x="400" data-y="345" data-speed="300" data-start="1600" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 383.75px; top: 381.188px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s58.png" alt="" src="/uploads/general/images-slider/s58.png" style="width: 162.134px; height: 148.8px;">
                    </div>
                    <div class="caption large_text sfb tp-caption start" data-x="640" data-y="310" data-speed="300" data-start="1700" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 614px; top: 347.594px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s59.png" alt="" src="/uploads/general/images-slider/s59.png" style="width: 141.028px; height: 182.4px;">
                    </div>
                    <div class="caption large_text lfl tp-caption start" data-x="320" data-y="295" data-speed="400" data-start="2000" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: -349px; top: 283.188px; visibility: visible;">
                        <a href="http://seats.stqgroup.com.sa/CatPage/MyCatPage?cat=turkey1"><img ng-src="/uploads/general/images-slider/s511.png" alt="" src="/uploads/general/images-slider/s511.png" style="width: 288.772px; height: 32.64px;"></a>
                    </div>
                </li>
				
				<li data-transition="fade" data-slotamount="20" data-masterspeed="300" data-thumb="/uploads/general/images-slider/thumbs/thumb1.jpg" style="width: 100%; height: 100%; overflow: hidden; visibility: visible; left: 0px; top: 0px; z-index: 18; opacity: 1;">
                    <!--  BACKGROUND IMAGE -->
                    <div class="slotholder"><img ng-src="/uploads/general/images-slider/wide4.jpg" alt="" class="defaultimg" style="height: 432px; width: 1175.76px; position: relative; left: -127.5px; top: 0px; opacity: 0;" src="/uploads/general/images-slider/wide4.jpg"></div>
                    <!-- THE CAPTIONS IN THIS SLIDE -->
                    <div class="tp-caption lft start" data-x="290" data-y="205" data-speed="500" data-start="500" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 278.219px; top: -146px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s510.png" alt="" src="/uploads/general/images-slider/s510.png" style="width: 345.375px; height: 86.4px;">
                    </div>
                    <div class="caption large_text lfl tp-caption start" data-x="850" data-y="125" data-speed="450" data-start="800" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: -323px; top: 120px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss51.png" alt="" src="/uploads/general/images-slider/ss51.png" style="width: 262.869px; height: 345.6px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="650" data-y="75" data-speed="300" data-start="1000" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 623.594px; top: -244px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss52.png" alt="" src="/uploads/general/images-slider/ss52.png" style="width: 243.681px; height: 184.32px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="500" data-y="60" data-speed="300" data-start="1100" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 479.688px; top: -181px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss53.png" alt="" src="/uploads/general/images-slider/ss53.png" style="width: 104.572px; height: 120.96px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="320" data-y="60" data-speed="300" data-start="1200" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 307px; top: -181px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss54.png" alt="" src="/uploads/general/images-slider/ss54.png" style="width: 107.45px; height: 120.96px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="70" data-y="60" data-speed="300" data-start="1300" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 67.1562px; top: -247px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss55.png" alt="" src="/uploads/general/images-slider/ss55.png" style="width: 209.144px; height: 187.2px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="-165" data-y="135" data-speed="300" data-start="1400" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: -158.297px; top: -335px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss56.png" alt="" src="/uploads/general/images-slider/ss56.png" style="width: 261.909px; height: 274.56px;">
                    </div>
                    <div class="caption large_text sfb tp-caption start" data-x="150" data-y="310" data-speed="300" data-start="1500" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 143.906px; top: 347.594px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss57.png" alt="" src="/uploads/general/images-slider/ss57.png" style="width: 149.662px; height: 179.52px;">
                    </div>
                    <div class="caption large_text sfb tp-caption start" data-x="400" data-y="355" data-speed="300" data-start="1600" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 383.75px; top: 390.797px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss58.png" alt="" src="/uploads/general/images-slider/ss58.png" style="width: 162.134px; height: 148.8px;">
                    </div>
                    <div class="caption large_text sfb tp-caption start" data-x="640" data-y="310" data-speed="300" data-start="1700" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 614px; top: 347.594px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/ss59.png" alt="" src="/uploads/general/images-slider/ss59.png" style="width: 141.028px; height: 182.4px;">
                    </div>
                    <div class="caption large_text lfl tp-caption start" data-x="320" data-y="300" data-speed="400" data-start="2000" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: -349px; top: 288px; visibility: visible;">
                        <a href="http://seats.stqgroup.com.sa/CatPage/MyCatPage?cat=turkey1"><img ng-src="/uploads/general/images-slider/s511.png" alt="" src="/uploads/general/images-slider/s511.png" style="width: 288.772px; height: 32.64px;"></a>
                    </div>
                </li>
				
				
               
                <li data-transition="fade" data-slotamount="20" data-masterspeed="300" data-thumb="/uploads/general/images-slider/thumbs/thumb1.jpg" style="width: 100%; height: 100%; overflow: hidden; visibility: visible; left: 0px; top: 0px; z-index: 18; opacity: 1;">
                    <!--  BACKGROUND IMAGE -->
                    <div class="slotholder"><img ng-src="/uploads/general/images-slider/wide2.jpg" alt="" class="defaultimg" style="height: 432px; width: 1175.76px; position: relative; left: -127.5px; top: 0px; opacity: 0;" src="/uploads/general/images-slider/wide2.jpg"></div>

                    <!-- THE CAPTIONS IN THIS SLIDE -->
                    <div class="caption large_text lft tp-caption start" data-x="600" data-y="85" data-speed="450" data-start="800" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 575.625px; top: -435px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s3-4.png" alt="" src="/uploads/general/images-slider/s3-4.png" style="width: 393.344px; height: 375.36px;">
                    </div>

                    <div class="tp-caption sfb start" data-x="130" data-y="95" data-speed="300" data-start="1000" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 124.719px; top: 141.188px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s3-1.png" alt="" src="/uploads/general/images-slider/s3-1.png" style="width: 257.113px; height: 19.2px;">
                    </div>

                    <div class="tp-caption sft start" data-x="0" data-y="125" data-speed="300" data-start="1200" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 0px; top: 70px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s3-2.png" alt="" src="/uploads/general/images-slider/s3-2.png" style="width: 495.037px; height: 51.84px;">
                    </div>

                    <div class="tp-caption sfb start" data-x="195" data-y="240" data-speed="300" data-start="1600" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 187.078px; top: 280.391px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s3-5.png" alt="" src="/uploads/general/images-slider/s3-5.png" style="width: 113.206px; height: 113.28px;">
                    </div>

                    <div class="tp-caption sfr start" data-x="350" data-y="230" data-speed="300" data-start="1800" data-easing="easeOutBack" style="font-size: 12px; padding: 0px; margin: 0px; border-width: 0px; line-height: 27px; white-space: nowrap; min-width: 0px; min-height: 0px; transform: scale(1, 1) rotate(0deg); opacity: 0; left: 385.781px; top: 220.797px; visibility: visible;">
                        <a href="/pages/أنظمة-الصوت"><div class="btn btn-warning"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sound systems</font></font></div></a>
                    </div>

                    <div class="tp-caption sfr start" data-x="357" data-y="300" data-speed="300" data-start="2000" data-easing="easeOutBack" style="font-size: 12px; padding: 0px; margin: 0px; border-width: 0px; line-height: 27px; white-space: nowrap; min-width: 0px; min-height: 0px; transform: scale(1, 1) rotate(0deg); opacity: 0; left: 392.484px; top: 288px; visibility: visible;">
                        <a href="/pages/الإسقاط-المرئي"><div class="btn btn-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Visual projection system</font></font></div></a>
                    </div>

                    <div class="tp-caption sfl start" data-x="330" data-y="365" data-speed="300" data-start="2200" data-easing="easeOutBack" style="font-size: 12px; padding: 0px; margin: 0px; border-width: 0px; line-height: 27px; white-space: nowrap; min-width: 0px; min-height: 0px; transform: scale(1, 1) rotate(0deg); opacity: 0; left: 266.594px; top: 350.391px; visibility: visible;">
                        <a href="/pages/المسرح-المنزلي"><div class="btn btn-info"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Home Theater</font></font></div></a>
                    </div>

                    <div class="tp-caption sfl start" data-x="148" data-y="410" data-speed="300" data-start="2400" data-easing="easeOutBack" style="font-size: 12px; padding: 0px; margin: 0px; border-width: 0px; line-height: 27px; white-space: nowrap; min-width: 0px; min-height: 0px; transform: scale(1, 1) rotate(0deg); opacity: 0; left: 91.9844px; top: 393.594px; visibility: visible;">
                        <a href="/pages/الاستوديوهات"><div class="btn btn-warning"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Studios and Plateaus</font></font></div></a>
                    </div>

                    <div class="tp-caption sfl start" data-x="45" data-y="365" data-speed="300" data-start="2600" data-easing="easeOutBack" style="font-size: 12px; padding: 0px; margin: 0px; border-width: 0px; line-height: 27px; white-space: nowrap; min-width: 0px; min-height: 0px; transform: scale(1, 1) rotate(0deg); opacity: 0; left: -6.82812px; top: 350.391px; visibility: visible;">
                        <a href="/pages/البعد-الثلاثي"><div class="btn btn-info"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">3D</font></font></div></a>
                    </div>

                    <div class="tp-caption sfl start" data-x="-25" data-y="300" data-speed="300" data-start="2800" data-easing="easeOutBack" style="font-size: 12px; padding: 0px; margin: 0px; border-width: 0px; line-height: 27px; white-space: nowrap; min-width: 0px; min-height: 0px; transform: scale(1, 1) rotate(0deg); opacity: 0; left: -73.9844px; top: 288px; visibility: visible;">
                        <a href="/pages/أنظمة-الترجمة-الفورية"><div class="btn btn-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Simultaneous translation systems</font></font></div></a>
                    </div>

                    <div class="tp-caption sfl start" data-x="40" data-y="230" data-speed="300" data-start="3000" data-easing="easeOutBack" style="font-size: 12px; padding: 0px; margin: 0px; border-width: 0px; line-height: 27px; white-space: nowrap; min-width: 0px; min-height: 0px; transform: scale(1, 1) rotate(0deg); opacity: 0; left: -11.625px; top: 220.797px; visibility: visible;">
                        <a href="/pages/أنظمة-الإضاءة"><div class="btn btn-warning"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Lighting systems</font></font></div></a>
                    </div>
                </li>
				 <li data-transition="fade" data-slotamount="20" data-masterspeed="300" data-thumb="/uploads/general/images-slider/thumbs/thumb1.jpg" style="width: 100%; height: 100%; overflow: hidden; visibility: visible; left: 0px; top: 0px; z-index: 18; opacity: 1;">
                    <!--  BACKGROUND IMAGE -->
                    <div class="slotholder"><img ng-src="/uploads/general/images-slider/wide-conf.jpg" alt="" class="defaultimg" style="height: 432px; width: 1175.76px; position: relative; left: -127.5px; top: 0px; opacity: 0;" src="/uploads/general/images-slider/wide-conf.jpg"></div>

                    <!-- THE CAPTIONS IN THIS SLIDE -->
                    <div class="caption large_text lfl tp-caption start" data-x="215" data-y="200" data-speed="450" data-start="400" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: -565px; top: 192px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/conf1.png" alt="" src="/uploads/general/images-slider/conf1.png" style="width: 504.631px; height: 107.52px;">
                    </div>

                    <div class="caption large_text lfr tp-caption start" data-x="330" data-y="300" data-speed="850" data-start="650" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 981px; top: 288px; visibility: visible;">
                        <a href="/pages/القاعات"><img ng-src="/uploads/general/images-slider/conf2.png" alt="" src="/uploads/general/images-slider/conf2.png" style="width: 287.812px; height: 31.68px;"></a>
                    </div>

                </li>
                <li data-transition="fade" data-slotamount="20" data-masterspeed="300" data-thumb="/uploads/general/images-slider/thumbs/thumb1.jpg" style="width: 100%; height: 100%; overflow: hidden; visibility: visible; left: 0px; top: 0px; z-index: 20; opacity: 1;">
                    <!--  BACKGROUND IMAGE -->
                    <div class="slotholder"><img ng-src="/uploads/general/images-slider/wide5.jpg" alt="" class="defaultimg" style="height: 432px; width: 1175.76px; position: relative; left: -127.5px; top: 0px; opacity: 1;" src="/uploads/general/images-slider/wide5.jpg"></div>

                    <!-- THE CAPTIONS IN THIS SLIDE -->

                    <div class="caption large_text lft tp-caption start" data-x="250" data-y="310" data-speed="200" data-start="400" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 239.844px; top: 297.6px; visibility: visible;">
                        <a href="seats.stqgroup.com.sa/CatPage/MyCatPage?cat=turkey1"><img ng-src="/uploads/general/images-slider/s67.png" alt="" src="/uploads/general/images-slider/s67.png" style="width: 464.337px; height: 28.8px;"></a>
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="260" data-y="340" data-speed="500" data-start="500" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 249.438px; top: 326.4px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s68.png" alt="" src="/uploads/general/images-slider/s68.png" style="width: 437.475px; height: 58.56px;">
                    </div>
                    <div class="caption large_text lft tp-caption start" data-x="260" data-y="410" data-speed="500" data-start="1700" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 249.438px; top: 393.6px; visibility: visible;">
                        <a href="http://seats.stqgroup.com.sa/"><img ng-src="/uploads/general/images-slider/s69.png" alt="" src="/uploads/general/images-slider/s69.png" style="width: 425.003px; height: 41.28px;"></a>
                    </div>


                    <div class="caption large_text lft tp-caption start" data-x="800" data-y="100" data-speed="450" data-start="800" data-easing="easeOutExpo" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 767.5px; top: 96px; visibility: visible;">
                        <a href="/pages/الستائر-المسرحية"><img ng-src="/uploads/general/images-slider/s61.png" alt="" src="/uploads/general/images-slider/s61.png" style="width: 168.85px; height: 195.84px;"></a>
                    </div>

                    <div class="caption large_text lft tp-caption start" data-x="600" data-y="100" data-speed="300" data-start="1000" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 575.625px; top: 96px; visibility: visible;">
                        <a href="/pages/أرضية-خشبة-المسرح"><img ng-src="/uploads/general/images-slider/s62.png" alt="" src="/uploads/general/images-slider/s62.png" style="width: 168.85px; height: 195.84px;"></a>
                    </div>

                    <div class="caption large_text lft tp-caption start" data-x="400" data-y="100" data-speed="300" data-start="1100" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 383.75px; top: 96px; visibility: visible;">
                        <a href="/pages/العزل-الصوتي"><img ng-src="/uploads/general/images-slider/s63.png" alt="" src="/uploads/general/images-slider/s63.png" style="width: 168.85px; height: 195.84px;"></a>
                    </div>

                    <div class="caption large_text lft tp-caption start" data-x="200" data-y="100" data-speed="300" data-start="1200" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 191.875px; top: 96px; visibility: visible;">
                        <a href="/pages/الأسقف-المعلقة"><img ng-src="/uploads/general/images-slider/s64.png" alt="" src="/uploads/general/images-slider/s64.png" style="width: 168.85px; height: 195.84px;"></a>
                    </div>

                    <div class="caption large_text lft tp-caption start" data-x="0" data-y="100" data-speed="300" data-start="1300" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 1; left: 0px; top: 96px; visibility: visible;">
                        <a href="/pages/المسارح-المتنقلة"><img ng-src="/uploads/general/images-slider/s65.png" alt="" src="/uploads/general/images-slider/s65.png" style="width: 168.85px; height: 195.84px;"></a>
                    </div>
                </li>
                <li data-transition="fade" data-slotamount="20" data-masterspeed="300" data-thumb="/uploads/general/images-slider/thumbs/thumb1.jpg" style="width: 100%; height: 100%; overflow: hidden; visibility: visible; left: 0px; top: 0px; z-index: 18; opacity: 1;">
                    <!--  BACKGROUND IMAGE -->
                    <div class="slotholder"><img ng-src="/uploads/general/images-slider/wide1.jpg" alt="" class="defaultimg" style="height: 432px; width: 1175.76px; position: relative; left: -127.5px; top: 0px; opacity: 0;" src="/uploads/general/images-slider/wide1.jpg"></div>

                    <!-- THE CAPTIONS IN THIS SLIDE -->
                    <div class="caption large_text lfl tp-caption start" data-x="580" data-y="70" data-speed="450" data-start="400" data-easing="easeOutExpo" style="left: -477px; transform: scale(1, 1) rotate(0deg); opacity: 1; top: 67.1875px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s1-main.png" alt="" src="/uploads/general/images-slider/s1-main.png" style="width: 417.328px; height: 393.6px;">
                    </div>

                    <div class="caption large_text lfr tp-caption start" data-x="380" data-y="225" data-speed="850" data-start="650" data-easing="easeOutExpo" style="left: 981px; transform: scale(1, 1) rotate(0deg); opacity: 1; top: 216px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s1-1.png" alt="" src="/uploads/general/images-slider/s1-1.png" style="width: 143.906px; height: 136.32px;">
                    </div>
                    <div class="caption large_text lfr tp-caption start" data-x="230" data-y="270" data-speed="150" data-start="750" data-easing="easeOutExpo" style="left: 981px; transform: scale(1, 1) rotate(0deg); opacity: 1; top: 259.188px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s1-2.png" alt="" src="/uploads/general/images-slider/s1-2.png" style="width: 109.369px; height: 97.92px;">
                    </div>

                    <div class="tp-caption lft start" data-x="-40" data-y="240" data-speed="450" data-start="900" data-easing="easeOutBack" style="top: -189px; transform: scale(1, 1) rotate(0deg); opacity: 1; left: -38.375px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s1-3.png" alt="" src="/uploads/general/images-slider/s1-3.png" style="width: 243.681px; height: 128.64px;">
                    </div>



                    <div class="tp-caption sfb start" data-x="20" data-y="125" data-speed="300" data-start="1000" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 19.1875px; top: 170px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s1-t1.png" alt="" src="/uploads/general/images-slider/s1-t1.png" style="width: 412.531px; height: 24.96px;">
                    </div>

                    <div class="tp-caption sft start" data-x="18" data-y="155" data-speed="300" data-start="1200" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 17.2656px; top: 98.7969px; visibility: visible;">
                        <img ng-src="/uploads/general/images-slider/s1-t2.png" alt="" src="/uploads/general/images-slider/s1-t2.png" style="width: 423.084px; height: 48px;">
                    </div>
                    <div class="tp-caption sfb start" data-x="30" data-y="405" data-speed="300" data-start="1600" data-easing="easeOutBack" style="transform: scale(1, 1) rotate(0deg); opacity: 0; left: 28.7812px; top: 438.797px; visibility: visible;">
                        <a href="http://safety.stqgroup.com.sa"><img ng-src="/uploads/general/images-slider/s1-t3.png" alt="" src="/uploads/general/images-slider/s1-t3.png" style="width: 415.409px; height: 26.88px;"></a>
                    </div>
                </li>
            </ul>
        <div class="tp-loader" style="display: none;"></div><div class="tp-bannertimer" style="visibility: hidden; width: 60.3933%; overflow: hidden;"></div></div>
    <div style="position: absolute; top: 216px; margin-top: -20px; left: 20px; display: block;" class="tp-leftarrow tparrows default hidearrows"></div><div style="position: absolute; top: 216px; margin-top: -20px; right: 20px; display: block;" class="tp-rightarrow tparrows default hidearrows"></div></div>
    <!-- slider close -->
    <!-- call to action -->
    <div class="call-to-action" id="welcome">
        <div class="container ng-binding" ng-bind-html="getSetting('HomeBlocks1')"><div class="row">
<div class="col-md-3"><a class="btn btn-extra-large btn-primary" href="/pages/طلب%20مشروع"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Request your project now</font></font></a></div>
<div class="col-md-4">
<h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">For your business to succeed, you need experienced people to implement it.. </font></font><br><span class="id-color"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">STQ Group.. The Straightforward Group</font></font></span></h5>
</div>
<div class="col-md-4">
<div class="col-md-4"><a class="btn btn-extra-large btn-primary" href="/9/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">View our latest projects</font></font></a></div>
</div>
</div></div>
    </div>
    <div id="content" class="no-bottom">
        <div class="container no-bottom">

            <div class="welcome">
                <div class="row welcm-left">
                    <div style="float: left; margin: 0px 36px 40px; width: 390px; height: 230px; padding: 20px 25px; box-shadow: 0px 5px 10px 0px #d4d4d4; border: 1px solid #d9d9d9;background: #fff;">
                        <iframe src="http://www.youtube.com/embed/_NEMiZWT-70?rel=0" width="340" height="190" frameborder="0"></iframe>
                    </div>
                    <div>
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..

   
                             </font></font><small style="font-size: 14px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
			     
	
 </font></font></small>
                            <br><br>
                        </h3>

                    </div>


      
                <div class="clearfix"></div>
            </div>
            <span id="services" ng-bind-html="getSetting('HomeBlocks3')" class="ng-binding"><div class="row">
<h4 class="col-md-12 ttl-bar"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Group activities and services</font></font></h4>
<div class="col-md-4">
<div class="team-item">
<div class="team-image"><img class="img-responsive" src="/Uploads/General/actv1.jpg" alt="author"></div>
<div class="team-text">
<h3><a href="/pages/تجهيزات-المسارح"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Theater equipment</font></font></a></h3>
</div>
</div>
</div>
 
<div class="col-md-4">
<div class="team-item">
<div class="team-image"><img class="img-responsive" src="/Uploads/General/actv10.jpg" alt="author"></div>
<div class="team-text">
<h3><a href="/pages/القاعات"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Meeting room equipment</font></font></a></h3>
</div>
</div>
</div>
 
<div class="col-md-4">
<div class="team-item">
<div class="team-image"><img class="img-responsive" src="/Uploads/General/actv7.jpg" alt="author"></div>
<div class="team-text">
<h3><a href="/pages/تجهيزات-المؤتمرات"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Conference Equipment</font></font></a></h3>
</div>
</div>
</div>
 
<div class="clearfix">&nbsp;</div>
</div>
<div class="row">
<div class="col-md-4">
<div class="team-item">
<div class="team-image"><img class="img-responsive" src="/Uploads/General/actv2.jpg" alt="author"></div>
<div class="team-text">
<h3><a href="/pages/الكراسي"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Supply and installation of theater chairs</font></font></a></h3>
</div>
</div>
</div>
 
<div class="col-md-4">
<div class="team-item">
<div class="team-image"><img class="img-responsive" src="/Uploads/General/actv8.jpg" alt="author"></div>
<div class="team-text">
<h3><a href="/pages/الأمن-والسلامة"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Safety and security equipment</font></font></a></h3>
</div>
</div>
</div>
 
<div class="col-md-4">
<div class="team-item">
<div class="team-image"><img class="img-responsive" src="/Uploads/General/actv9.jpg" alt="author"></div>
<div class="team-text">
<h3><a href="/pages/الإنتاج-الإعلامي"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Media production</font></font></a></h3>
</div>
</div>
</div>
</div></span>
            <span ng-bind-html="getSetting('HomeBlocks4')" class="ng-binding"><div class="container no-bottom gal">
<div class="ttl-bar"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Selections from the group's previous works</font></font></div>
<div class="row">
<div class="col-md-4"><a title="" href="/uploads/general/g5.jpg" target="_blank" rel="prettyPhoto[g]"><img src="/uploads/general/g5.jpg" alt=""></a></div>
<div class="col-md-4"><a title="" href="/uploads/general/g9.jpg" target="_blank" rel="prettyPhoto[g]"><img src="/uploads/general/g9.jpg" alt=""></a></div>
<div class="col-md-4"><a title="" href="/uploads/general/g3.jpg" target="_blank" rel="prettyPhoto[g]"><img src="/uploads/general/g3.jpg" alt=""></a></div>
</div>
<br>
<div class="row">
<div class="col-md-6 smallgal">
<div class="col-md-6"><a title="" href="/uploads/general/g4.jpg" target="_blank" rel="prettyPhoto[g]"><img src="/uploads/general/g4.jpg" alt=""></a></div>
<div class="col-md-6"><a title="" href="/uploads/general/g1.jpg" target="_blank" rel="prettyPhoto[g]"><img src="/uploads/general/g1.jpg" alt=""></a></div>
<div class="col-md-6"><a title="" href="/uploads/general/g6.jpg" target="_blank" rel="prettyPhoto[g]"><img src="/uploads/general/g6.jpg" alt=""></a></div>
<div class="col-md-6"><a title="" href="/uploads/general/g7.jpg" target="_blank" rel="prettyPhoto[g]"><img src="/uploads/general/g7.jpg" alt=""></a></div>
</div>
<div class="col-md-6"><a title="" href="/uploads/general/g8.jpg" rel="prettyPhoto[g]"><img src="/uploads/general/g8.jpg" alt="" width="700"></a></div>
</div>
</div></span>
            <div class="container no-bottom" ng-init="toptype=10;topitems=4;topparent=0">
                <div class="row">
                    <div class="ttl-bar"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        From the group news
                    </font></font></div>
                    <ul class="col-md-12 bloglist-small">
                        <!-- ngRepeat: item in topmedia --><li class="col-md-6 ng-scope" ng-repeat="item in topmedia" style="direction:rtl !important">
                            <div class="date-box">
                                <span class="day ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">02</font></font><small class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">September</font></font></small></span>
                                <span class="month ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2018</font></font></span>
                            </div>
                            <div class="txt">
                                <h5><a href="/10/4/5456" class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Completion of the Abha Literary Club Theater Project</font></font></a></h5>
                                <span class="read ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Thanks to God, the Abha Literary Club Theater project was completed in record time and with quality and precision that won the admiration and appreciation of the club’s management.</font></font></span>
                                <!--<span class="info"><a ng-href="/#/{{tid+'/'+item.ParentId+'/'+item.MediaId}}">اقرأ المزيد</a></span>-->
                            </div>
                        </li><!-- end ngRepeat: item in topmedia --><li class="col-md-6 ng-scope" ng-repeat="item in topmedia" style="direction:rtl !important">
                            <div class="date-box">
                                <span class="day ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">20</font></font><small class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">July</font></font></small></span>
                                <span class="month ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2020</font></font></span>
                            </div>
                            <div class="txt">
                                <h5><a href="/10/4/5611" class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Official visit to see the progress of work - Education Administration Theater - Taif Governorate.</font></font></a></h5>
                                <span class="read ng-binding"></span>
                                <!--<span class="info"><a ng-href="/#/{{tid+'/'+item.ParentId+'/'+item.MediaId}}">اقرأ المزيد</a></span>-->
                            </div>
                        </li><!-- end ngRepeat: item in topmedia --><li class="col-md-6 ng-scope" ng-repeat="item in topmedia" style="direction:rtl !important">
                            <div class="date-box">
                                <span class="day ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">06</font></font><small class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">July</font></font></small></span>
                                <span class="month ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2017</font></font></span>
                            </div>
                            <div class="txt">
                                <h5><a href="/10/4/3355" class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Al-Istiqama Group expands in the field of security and safety</font></font></a></h5>
                                <span class="read ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Al-Istiqaama Group has appointed a new team and cadres with the highest experience in the field of security and safety, in addition to updating all security and safety requirements and equipment for the year 2016 AD.
</font></font></span>
                                <!--<span class="info"><a ng-href="/#/{{tid+'/'+item.ParentId+'/'+item.MediaId}}">اقرأ المزيد</a></span>-->
                            </div>
                        </li><!-- end ngRepeat: item in topmedia --><li class="col-md-6 ng-scope" ng-repeat="item in topmedia" style="direction:rtl !important">
                            <div class="date-box">
                                <span class="day ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">06</font></font><small class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">July</font></font></small></span>
                                <span class="month ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2017</font></font></span>
                            </div>
                            <div class="txt">
                                <h5><a href="/10/4/5435" class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Delivery of Hawtah Bani Tamim project</font></font></a></h5>
                                <span class="read ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">The completion of the Hawtah Bani Tamim Theater has been delivered</font></font></span>
                                <!--<span class="info"><a ng-href="/#/{{tid+'/'+item.ParentId+'/'+item.MediaId}}">اقرأ المزيد</a></span>-->
                            </div>
                        </li><!-- end ngRepeat: item in topmedia -->
                    </ul>
                </div>
            </div>
        </div>

        <!-- project close -->
        <!-- parallax content begin -->
        <section id="full-content-1" class="border-top border-bottom no-bottom" data-speed="8" data-type="background">
            <div class="container">
                <div class="row">
                    <div class="span12 text-center">
                        <h1 class="animated wow fadeInDown" data-wow-duration="1500" style="margin-top: -15px; visibility: hidden; animation-name: none;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                            Integrity of security and safety systems..
                        </font></font></h1>

                        <h3 class="med-white wow fadeInDown" data-wow-duration="1500" data-wow-delay="0.2s" style="visibility: hidden; animation-delay: 0.2s; animation-name: none;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">A team of professionals in the field of security and safety.</font></font></h3>
                        <p class="animated wow fadeInDown" data-wow-duration="1500" data-wow-delay="0.2s" style="visibility: hidden; animation-delay: 0.2s; animation-name: none;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">

                            Al-Istiqama Group carefully studies, prepares and implements accurately using the latest global technologies recommended in the field of security and safety.

                        </font></font></p><p>
                        </p><p class="animated wow fadeInDown" data-wow-duration="1500" data-wow-delay="0.2s" style="visibility: hidden; animation-delay: 0.2s; animation-name: none;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">To view our services in the field of security and safety .. </font></font><a href="/pages/الأمن-والسلامة" style="color:#fff;text-decoration:underline"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">click here</font></font></a></p>
                        <img style="margin-top: -15px; visibility: hidden; animation-delay: 0.2s; animation-name: none;" ng-src="images/idevice.png" alt="" class="animated wow slideInLeft" data-wow-duration="1500" data-wow-delay="0.2s" src="images/idevice.png">
                    </div>
                </div>
            </div>
        </section>
    </div>
</div><!-- end ngIf: isHome --></div>
        <!-- ngInclude: '/app/views/_footer.html' --><div ng-include="'/app/views/_footer.html'" class="ng-scope"><!-- footer begin -->
<section class="hidden ng-scope" id="footeradv-full" data-speed="8" data-type="background" style="background: url(/uploads/general/images-slider/wide1.jpg) top center !important">
    <div class="container">
        <div class="row">
            <div class="flexslider testi-slider">
                <ul class="slides">
                    <li style="width: 100%; float: left; margin-right: -100%; position: relative; opacity: 1; display: block; z-index: 2;" class="flex-active-slide">
                        <div style="margin:15px auto -15px; height:140px;width:100%; background:url(/uploads/general/images-slider/footer1.png) no-repeat center bottom"></div>
                    </li>
                    <li style="width: 100%; float: left; margin-right: -100%; position: relative; opacity: 0; display: block; z-index: 1;">
                        <div style="margin:15px auto -15px; height:140px;width:100%; background:url(/uploads/general/images-slider/footer2.png) no-repeat center bottom"></div>
                    </li>
                </ul>
            <ol class="flex-control-nav flex-control-paging"><li><a class="flex-active">1</a></li><li><a>2</a></li></ol><ul class="flex-direction-nav"><li class="flex-nav-prev"><a class="flex-prev" href="#">Previous</a></li><li class="flex-nav-next"><a class="flex-next" href="#">Next</a></li></ul></div>
        </div>
    </div>
</section>
<br class="ng-scope">
<footer class="ng-scope">
    <div class="container">
        <div class="row">
            <iframe style="width:100%;height:100%;min-height:220px" src="https://maps.google.com/maps/ms?msa=0&amp;msid=210018892680451878443.0004dc1160f9ddff99b0e&amp;ie=UTF8&amp;ll=26.096985,43.982522&amp;spn=0,0&amp;t=m&amp;iwloc=0004dc1160fe9ad2d1928&amp;output=embed" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>


            <!--<div class="col-md-3 fabout">
        <img src="/images/logo-small.png" alt="logo"><br><br>
        نشأت المجموعة منذ أكثر من 30 عاماً كمنشأة إعلامية تمتلك استديوهات وبلاتوهات تصوير حيث تعتبر المجموعة من رواد الصناعة الإعلامية في المملكة العربية السعودية حيث تمتلك استوديوهات رقمية وفريق عمل متخصص .
        <br />
        وحديثا توسعت المجموعة وأنشأت عدة أقسام تخدم النشاط الأساسي لها لتكتم"ooooooooooooooooooooooo">المزيد</a>
    </div>

    <div class="col-md-6">
    </div>-->


     
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">To contact us:</font></font></h3>
                <div class="widget widget-address">
                    <address>
                        <strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Al-Istiqama Group for Theater and Hall Equipment</font></font></strong>
                        <br><br>
                        <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Kingdom of Saudi Arabia</font></font></span>
                        <!--<span>الرياض: الملز .. هاتف: 966549114052+</span>
                <br />-->
                        <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                            Qassim - Unaizah - P.O. Box: 1502 - Postal Code: 51911
                        </font></font></span>
                        <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Phone: +9660000000</font></font></span>
                        <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Fax: +966000000000</font></font></span>
                        <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Email: </font></font><a href="mailto:ooooooooooooo"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ooooooooooooooo</font></font></a></span>
                    </address>
                </div>
            </div>
        </div>
    </div>

    <div class="subfooter">
        <div class="container">
            <div class="row">
                <div class="col-md-6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    © All rights reserved - Al-Istiqama for Theater and Hall Equipment
                </font></font></div>
                <div class="col-md-6">
                    <nav>
                        <ul>
                            <li><a href="/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Home</font></font></a></li>
                            <li><a href="#welcome"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Who we are</font></font></a></li>
                            <li><a href="#services"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Our services</font></font></a></li>
                            <li><a href="/9"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Our projects</font></font></a></li>
                            <li><a href="/10/4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Our news</font></font></a></li>
                            <li><a href="/pages/اتصل-بنا"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Contact us</font></font></a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

</footer>
<!-- footer close --></div>
    </div>



    <!-- CSS Files
    ================================================== -->
    <link rel="stylesheet" href="/css/main.css" type="text/css" id="main-css">
    <link rel="stylesheet" href="/css/wide-screen.css" type="text/css" id="wide">
    <link rel="stylesheet" href="/css/sass-compiled.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Javascript Files
    ================================================== -->
    <script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-Q2JERS7R48&amp;cx=c&amp;_slc=1"></script><script type="text/javascript" async="" charset="utf-8" src="https://www.gstatic.com/recaptcha/releases/p09oe8YIFfKgcnqQ9m9k4aiB/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-+o4WMEIVaqJv2OSyUGcZwITebuccICWoZiIEvjf6rbs34UX8HV3S+g6ypB1KhLvK"></script><script async="" src="https://www.google-analytics.com/analytics.js"></script><script src="/bundles/jquery?v=gkWyJthHPtwkFjvHuNinBjchIfwLwc_KbE-H26J2kAI1"></script>

    <script src="/bundles/js?v=d4Ymqc65FC1-ZlB__lLeVR6Y13bt_J62LJajAVANMes1"></script>

    <script src="/bundles/rev?v=AazH0u3H-Os6Vxr2JWJ_VnfkqfBD94t2yWXY5Tq_nP41"></script>

    <style>
        .wow:first-child { visibility: hidden; }
		.wfloat{
	position:fixed;
	width:60px;
	height:60px;
	bottom:150px;
	right:150px;
	background-color:#25d366;
	color:#FFF  !important;
	border-radius:50px;
	text-align:center;
  font-size:40px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}
 .wfloat span {
    background-color: #25d366;
    display: inline-block;
    padding: 5px;
    font-size: 14px !important;
    position: absolute;
    width: 120px;
    margin: 12px -8px;
    border-radius: 20px;
    z-index: -1;
}  
.my-wfloat{
	    float: none !important;
    margin: 12px auto auto 2px !important;
}
    </style>
	
<a href="https://api.whatsapp.com/send?phone=00630000000&amp;text=%D9%86%D8%B3%D8%B9%D8%AF%20%D8%A8%D8%AA%D9%88%D8%A7%D8%B5%D9%84%D9%83%D9%85%20%D9%85%D8%B9%D9%86%D8%A7%20..
	%20%D9%85%D8%AC%D9%85%D9%88%D8%B9%D8%A9%20%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D9%82%D8%A7%D9%85%D8%A9%20%D9%84%D8%AA%D8%AC%D9%87%D9%
	8A%D8%B2%D8%A7%D8%AA%20%D8%A7%D9%84%D9%85%D8%B3%D8%A7%D8%B1%D8%AD%20%D9%88%D8%A7%D9%84%D9%82%D8%A7%D8%B9%D8%A7%D8%A
" class="wfloat" target="_blank">
<i class="fa fa-whatsapp my-wfloat"></i> <span><font style="vertical-align: inherit;">
<font style="vertical-align: inherit;">Contact us</font></font></span>

</a>
    
    <script src="/app/shared/angular.min.1.4.9.js"></script>
    <!--<script src="//ajax.googleapis.com/ajax/libs/angularjs/1.4.7/angular.js"></script>-->
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.4.9/angular-animate.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.4.9/angular-sanitize.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ngStorage/0.3.6/ngStorage.min.js"></script>
    <script src="//angular-ui.github.io/bootstrap/ui-bootstrap-tpls-1.3.1.js"></script>
    <!-- Include the AngularJS routing library -->
    <script src="https://code.angularjs.org/1.4.9/angular-route.min.js"></script>
    
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.4.9/angular-messages.js"></script>

    <script src="https://www.google.com/recaptcha/api.js?onload=vcRecaptchaApiLoaded&amp;render=explicit" async="" defer=""></script>
    <script src="/Scripts/angular-recaptcha.min.js"></script>


    

    <!-- Modules -->
    <script src="/app/app.js"></script>

    <!-- Controllers -->
    <script src="/app/controllers/HomeController.js"></script>
    <script src="/app/controllers/DetailsController.js"></script>
    <script src="/app/controllers/PagesController.js"></script>

    <!-- Services -->
    <script src="/app/services/media.js"></script>
    <script src="/app/services/pages.js"></script>
    <script type="text/javascript" charset="utf-8">
        app.run(function ($rootScope, $filter) {
            $rootScope.GSettings = [{"k":"Sitename","v":"تجهيزات المسارح والقاعات - مجموعة الاستقامة STQ"},{"k":"SiteDescription","v":"مجموعة الاستقامة - تجهيز المسارح وتنفيذ وتوريد وتركيب أنظمة وأجهزة الإضاءة والصوتيات الاحترافية وجميع أنواع الكراسي والستائر والديكورات والعزل الصوتي للمسارح وقاعات المؤتمرات والإستديوهات .. إضافة إمكانية عرض الأفلام ثلاثية الأبعاد Dimension Cinema ذات التأثيرات المجسمة في الصورة والصوت في المسارح إضافة نظام الاجتماعات المزودة بالأجهزة Audio Video صوتي ومرئي . عرض نتائج اللإقتراع السري في ثواني . نظام الترجمة الفورية للمؤتمرات IR Assistive Listening System تعمل بالأشعة الحمراء حتى 4 لغات ومضاعفاتها . استخدام المسرح كقاعة تدريب وتعليم ورفع مستوى القيادات من خلال السبورة الذكية والشاشات العملاقة وأجهزة العرض 3D والمؤتمرات الصوتية المميزة و تجهيز وتركيب أنظمة المؤتمرات المرئية الVideo Conference. تحويل العرض في المسارح الكبيرة إلى نظام عرض سينمائي . عمل جميع التصاميم والمواصفات الهندسية لجميع الأعمال ويوجد فريق من المهندسين المتخصصين وذوى الخبرة الكبيرة بهذا المجال . توريد وتركيب كاميرات المراقبة والدوائر التلفزيونية المغلقة (C.C.T.V) وأجهزة الأمن والسلامة ونظام السيكورتى. "},{"k":"Works","v":"on"},{"k":"CloseText","v":"\u003cp\u003eالموقع في حالة صيانة .. سنعود سريعا إن شاء الله\u003c/p\u003e"},{"k":"LeftCol","v":""},{"k":"FormEmail","v":"gm@stqgroup.com.sa"},{"k":"SiteKeywords","v":"مسارح,تجهيز,تجهيز مسارح,تجهيز المسارح,تجهيزات المسارح, المسارح والقاعات , القاعات المدرسية, مسارح مدرسية , مسارح مدرسية متنقلة , تجهيز قاعات التدريب , أنظمة الأمن والسلامة ,القاعات , الصالات ,المسارح, مجموعة الاستقامة, استوديوهات, وزارة التربية والتعليم ,المملكة العربية السعودية, تعليم, السعودية, انتاج اعلامي, مونتاج , ستوديو صوت , قاعات محاضرات , قاعات مؤتمرات , إضاءة مسارح , تصوير, المملكة, مسارح, تجهيزات مسارح, صناعة المسرح ، صالات مغطاه ، أنظمة إضاءة ، أمن وسلامة , ,اجهزة الامن والسلامة,اشكال مسارح,اضاءة المسارح,الاستقامة,الرمز البريدي عنيزة,العزل الصوتي في المسارح,المسارح,تجهيز قاعات المؤتمرات,تجهيز مسارح,تجهيزات المسارح,تجهيزمسرح باجهزة الاضاءة,تصاميم مسارح,تصميم مسارح مدرسية,تصميم مسرح مدرسي,ديكور مسارح مدرسية,ديكورات مسارح مدرسية,ستائر بالريموت في الرياض,ستائر كهربائية للمنازل,شركات الانتاج الاعلامي بالرياض,شركات تجهيز المسارح,شركات تجهيز قاعات الاجتماعات,شركات تجهيز قاعات المؤتمرات,شركة انتاج اعلامي,قاعات المؤتمرات في الرياض,قاعات مؤتمرات الرياض,قاعات مؤتمرات بالرياض,قاعات مؤتمرات في الرياض,كراسى بار خشب,كراسي قاعات مؤتمرات,كراسي مسرح,كشاف كومباكت,مسارح,مسرح الغرفة,ورق جدران عازل للصوت"},{"k":"LatestVideos","v":"6"},{"k":"Mobile","v":"0000000"},{"k":"Address","v":"المملكة العربية السعودية \r\nفرع الرياض: الملز .. هاتف: 966000000+\r\nفرع القصيم - محافظة عنيزة - ص . ب : 1502 - الرمز البريدى : 51911 \r\nهاتف: 966000000+   فاكس: 96600000+ "},{"k":"TopBannerAlbumId","v":"2"},{"k":"RtTopAdv","v":""},{"k":"LtTopAdv","v":""},{"k":"LtBtmAdv","v":""},{"k":"HomeAdvTop","v":""},{"k":"HomeAdvBottom","v":""},{"k":"FooterBannerAlbumID","v":"6"},{"k":"FooterBannerItems","v":"20"},{"k":"TopBannerItems","v":"20"},{"k":"SmtpUser","v":"gm@stqgroup.com.sa"},{"k":"SiteAnalytics","v":" (function(i,s,o,g,r,a,m){i[\u0027GoogleAnalyticsObject\u0027]=r;i[r]=i[r]||function(){\r\n  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\r\n  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\r\n  })(window,document,\u0027script\u0027,\u0027https://www.google-analytics.com/analytics.js\u0027,\u0027ga\u0027);\r\n\r\n  ga(\u0027create\u0027, \u0027UA-76286661-1\u0027, \u0027auto\u0027);\r\n  ga(\u0027send\u0027, \u0027pageview\u0027);"},{"k":"HomeBlocks1","v":"\u003cdiv class=\"row\"\u003e\r\n\u003cdiv class=\"col-md-3\"\u003e\u003ca class=\"btn btn-extra-large btn-primary\" href=\"/pages/طلب%20مشروع\"\u003eاطلب مشروعك الآن\u003c/a\u003e\u003c/div\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\r\n\u003ch5 style=\"margin-top: 0; text-align: center;\"\u003eلكي ينجح عملك عليك بأهل الخبرة لتنفيذه .. \u003cbr /\u003e\u003cspan class=\"id-color\" style=\"font-size: 21px;\"\u003eSTQ Group .. مجموعة الاستقامة \u003c/span\u003e\u003c/h5\u003e\r\n\u003c/div\u003e\r\n\u003cdiv class=\"col-md-4\" style=\"width: 30%;\"\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\u003c!--\u003ca class=\"btn btn-extra-large btn-primary\" style=\"padding-top: 7px;\" href=\"/pages/طلب%20مشروع\"\u003e\u003cspan style=\"font-size: 20px;\"\u003eللإتصال والتعاقد :\u003c/span\u003e 9660000000+ \u0026nbsp;\u003cimg style=\"width: 20px; padding-top: 3px;\" src=\"/uploads/general/whatsapp.png\" alt=\"\" /\u003e \u003c/a\u003e--\u003e\u003ca class=\"btn btn-extra-large btn-primary\" href=\"/9/\"\u003e الإطلاع على أحدث مشاريعنا \u003c/a\u003e\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e"},{"k":"HomeBlocks2","v":"\u003cdiv id=\"نبذة-عنا\"\u003eنحن مجموعة الاستقامة لتنفيذ وتوريد وتركيب جميع الأنظمة الخاصة بأجهزة الإضاءة والصوتيات المسرحية الاحترافية وقاعات المؤتمرات والإستديوهات . توريد وتركيب جميع أنواع الكراسي والستائر والديكورات والعزل للمسارح وقاعات المؤتمرات والإستديوهات . إضافة إمكانية عرض الأفلام ثلاثية الأبعاد Dimension Cinema ذات التأثيرات المجسمة في الصورة والصوت في المسارح إضافة نظام الاجتماعات المزودة بالأجهزة Audio Video صوتي ومرئي . عرض نتائج اللإقتراع السري في ثواني . نظام الترجمة الفورية للمؤتمرات IR Assistive Listening System تعمل بالأشعة الحمراء حتى 4 لغات ومضاعفاتها . استخدام المسرح كقاعة تدريب وتعليم ورفع مستوى القيادات من خلال السبورة الذكية والشاشات العملاقة وأجهزة العرض 3D والمؤتمرات الصوتية المميزة و تجهيز وتركيب أنظمة المؤتمرات المرئية الVideo Conference. تحويل العرض في المسارح الكبيرة إلى نظام عرض سينمائي . عمل جميع التصاميم والمواصفات الهندسية لجميع الأعمال ويوجد فريق من المهندسين المتخصصين وذوى الخبرة الكبيرة بهذا المجال . توريد وتركيب كاميرات المراقبة والدوائر التلفزيونية المغلقة (C.C.T.V) وأجهزة الأمن والسلامة ونظام السيكورتى.\u003c/div\u003e"},{"k":"HomeBlocks3","v":"\u003cdiv class=\"row\"\u003e\r\n\u003ch4 class=\"col-md-12 ttl-bar\"\u003eأنشطة وخدمات المجموعة\u003c/h4\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\r\n\u003cdiv class=\"team-item\"\u003e\r\n\u003cdiv class=\"team-image\"\u003e\u003cimg class=\"img-responsive\" src=\"/Uploads/General/actv1.jpg\" alt=\"author\" /\u003e\u003c/div\u003e\r\n\u003cdiv class=\"team-text\"\u003e\r\n\u003ch3\u003e\u003ca href=\"/pages/تجهيزات-المسارح\"\u003eتجهيزات المسارح\u003c/a\u003e\u003c/h3\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c!-- end team member item --\u003e \u003c!-- team member item --\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\r\n\u003cdiv class=\"team-item\"\u003e\r\n\u003cdiv class=\"team-image\"\u003e\u003cimg class=\"img-responsive\" src=\"/Uploads/General/actv10.jpg\" alt=\"author\" /\u003e\u003c/div\u003e\r\n\u003cdiv class=\"team-text\"\u003e\r\n\u003ch3\u003e\u003ca href=\"/pages/القاعات\"\u003e تجهيزات قاعات الاجتماعات \u003c/a\u003e\u003c/h3\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c!-- end team member item --\u003e \u003c!-- team member item --\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\r\n\u003cdiv class=\"team-item\"\u003e\r\n\u003cdiv class=\"team-image\"\u003e\u003cimg class=\"img-responsive\" src=\"/Uploads/General/actv7.jpg\" alt=\"author\" /\u003e\u003c/div\u003e\r\n\u003cdiv class=\"team-text\"\u003e\r\n\u003ch3\u003e\u003ca href=\"/pages/تجهيزات-المؤتمرات\"\u003e تجهيزات المؤتمرات \u003c/a\u003e\u003c/h3\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c!-- end team member item --\u003e \u003c!-- team member item --\u003e\r\n\u003cdiv class=\"clearfix\"\u003e\u0026nbsp;\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003cdiv class=\"row\"\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\r\n\u003cdiv class=\"team-item\"\u003e\r\n\u003cdiv class=\"team-image\"\u003e\u003cimg class=\"img-responsive\" src=\"/Uploads/General/actv2.jpg\" alt=\"author\" /\u003e\u003c/div\u003e\r\n\u003cdiv class=\"team-text\"\u003e\r\n\u003ch3\u003e\u003ca href=\"/pages/الكراسي\"\u003e توريد وتركيب كراسي المسرح \u003c/a\u003e\u003c/h3\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c!-- end team member item --\u003e \u003c!-- team member item --\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\r\n\u003cdiv class=\"team-item\"\u003e\r\n\u003cdiv class=\"team-image\"\u003e\u003cimg class=\"img-responsive\" src=\"/Uploads/General/actv8.jpg\" alt=\"author\" /\u003e\u003c/div\u003e\r\n\u003cdiv class=\"team-text\"\u003e\r\n\u003ch3\u003e\u003ca href=\"/pages/الأمن-والسلامة\"\u003e تجهيزات الأمن والسلامة \u003c/a\u003e\u003c/h3\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c!-- end team member item --\u003e \u003c!-- team member item --\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\r\n\u003cdiv class=\"team-item\"\u003e\r\n\u003cdiv class=\"team-image\"\u003e\u003cimg class=\"img-responsive\" src=\"/Uploads/General/actv9.jpg\" alt=\"author\" /\u003e\u003c/div\u003e\r\n\u003cdiv class=\"team-text\"\u003e\r\n\u003ch3\u003e\u003ca href=\"/pages/الإنتاج-الإعلامي\"\u003e الإنتاج الإعلامي \u003c/a\u003e\u003c/h3\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c!-- end team member item --\u003e\u003c/div\u003e"},{"k":"HomeBlocks4","v":"\u003cdiv class=\"container no-bottom gal\"\u003e\r\n\u003cdiv class=\"ttl-bar\"\u003eمختارات من سابقة أعمال المجموعة\u003c/div\u003e\r\n\u003cdiv class=\"row\"\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\u003ca title=\"\" href=\"/uploads/general/g5.jpg\" target=\"_blank\" rel=\"prettyPhoto[g]\"\u003e\u003cimg src=\"/uploads/general/g5.jpg\" alt=\"\" /\u003e\u003c/a\u003e\u003c/div\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\u003ca title=\"\" href=\"/uploads/general/g9.jpg\" target=\"_blank\" rel=\"prettyPhoto[g]\"\u003e\u003cimg src=\"/uploads/general/g9.jpg\" alt=\"\" /\u003e\u003c/a\u003e\u003c/div\u003e\r\n\u003cdiv class=\"col-md-4\"\u003e\u003ca title=\"\" href=\"/uploads/general/g3.jpg\" target=\"_blank\" rel=\"prettyPhoto[g]\"\u003e\u003cimg src=\"/uploads/general/g3.jpg\" alt=\"\" /\u003e\u003c/a\u003e\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003cbr /\u003e\r\n\u003cdiv class=\"row\"\u003e\r\n\u003cdiv class=\"col-md-6 smallgal\"\u003e\r\n\u003cdiv class=\"col-md-6\"\u003e\u003ca title=\"\" href=\"/uploads/general/g4.jpg\" target=\"_blank\" rel=\"prettyPhoto[g]\"\u003e\u003cimg src=\"/uploads/general/g4.jpg\" alt=\"\" /\u003e\u003c/a\u003e\u003c/div\u003e\r\n\u003cdiv class=\"col-md-6\"\u003e\u003ca title=\"\" href=\"/uploads/general/g1.jpg\" target=\"_blank\" rel=\"prettyPhoto[g]\"\u003e\u003cimg src=\"/uploads/general/g1.jpg\" alt=\"\" /\u003e\u003c/a\u003e\u003c/div\u003e\r\n\u003cdiv class=\"col-md-6\"\u003e\u003ca title=\"\" href=\"/uploads/general/g6.jpg\" target=\"_blank\" rel=\"prettyPhoto[g]\"\u003e\u003cimg src=\"/uploads/general/g6.jpg\" alt=\"\" /\u003e\u003c/a\u003e\u003c/div\u003e\r\n\u003cdiv class=\"col-md-6\"\u003e\u003ca title=\"\" href=\"/uploads/general/g7.jpg\" target=\"_blank\" rel=\"prettyPhoto[g]\"\u003e\u003cimg src=\"/uploads/general/g7.jpg\" alt=\"\" /\u003e\u003c/a\u003e\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003cdiv class=\"col-md-6\"\u003e\u003ca title=\"\" href=\"/uploads/general/g8.jpg\" rel=\"prettyPhoto[g]\"\u003e\u003cimg style=\"max-height: 100% !importamt; padding: 0;\" src=\"/uploads/general/g8.jpg\" alt=\"\" width=\"700\" /\u003e\u003c/a\u003e\u003c/div\u003e\r\n\u003c/div\u003e\r\n\u003c/div\u003e"},{"k":"HomeBlocks5","v":""}];
            $rootScope.getSetting = function(key) {
                var found = $filter('filter')($rootScope.GSettings, {k: key}, true);
                if (found.length) {
                    $rootScope.selected = found[0];
                } else {
                    $rootScope.selected = {};
                }
                return $rootScope.selected.v;
            }
            $rootScope.sitename = $rootScope.getSetting("Sitename");
            $rootScope.siteDescription = $rootScope.getSetting("SiteDescription");
            $rootScope.siteKeywords = $rootScope.getSetting("SiteKeywords");
            $rootScope.pagename ="";

            ///seo
            $rootScope.$on('$routeChangeSuccess', function () {
                var interval = setInterval(function () {
                    if (document.readyState == 'complete') {
                        //code that executes when partial view is loaded
                        //find the main heading tag for the help topic
                        var heading = document.querySelector('#subheader h1');
                        if (heading !== null) {
                            // set page title to topic heading
                            document.title = heading.textContent.trim() + " - "+$rootScope.sitename;//' - مجموعة الاستقامة لتجهيزات المسارح والقاعات والاستوديوهات STQ Group';
                        }
                        //find meta description tag
                        // var meta = document.querySelector('meta[name=description]');
                        //var meta2 = document.querySelector('meta[name=keyword]');
                        //find first paragraph in the help topic that isn't empty
                        // var content = document.querySelector('#content .col-md-9>div:not(:empty)');
                        //if (meta !== null && content !== null) {
                        //    // set meta description to content of first paragraph in topic
                        //  //  meta.setAttribute('content', content.textContent.trim());
                        //}
                        //if(meta2 !== null){
                        //   // meta2.setAttribute('content', $rootScope.siteKeywords.trim());
                        //}
                    }
                }, 200);
            });
        });

        //-------------------------------wow animate on scroll -------------------------
        jQuery(document).ready(function () {
            wow = new WOW(
                            {
                                boxClass: 'wow',
                                animateClass: 'animated',
                                offset: 10,
                                mobile: true,
                                live: true
                            }
                          )
            wow.init();
        });
        //TOUCH FRIENDLY IN MOBILE DEVICES
        document.addEventListener("touchstart", function(){}, true);

        jQuery.browser = {};
        (function () {
            jQuery.browser.msie = false;
            jQuery.browser.version = 0;
            if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
                jQuery.browser.msie = true;
                jQuery.browser.version = RegExp.$1;
            }
        })();
    </script>

    <script src="/bundles/other?v=gzh2ElttPxbO7O3j6Zop5p89j-f78ouaD1JRnJyYT-I1"></script>


    <link href="/css/melements/mediaelementplayer.min.css" rel="stylesheet">
    <script src="/Scripts/melements/mediaelement-and-player.min.js" type="text/javascript"></script>

    <script>
        $('#videoPlayer21').mediaelementplayer();
    </script>

    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-76286661-1', 'auto');
        ga('send', 'pageview');

    </script>

<div id="goog-gt-tt" class="VIpgJd-yAWNEb-L7lbkb skiptranslate" style="border-radius: 12px; margin: 0 0 0 -23px; padding: 0; font-family: 'Google Sans', Arial, sans-serif;" data-id=""><div id="goog-gt-vt" class="VIpgJd-yAWNEb-hvhgNd"><div class=" VIpgJd-yAWNEb-hvhgNd-l4eHX-i3jM8c"><img src="https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg" width="24" height="24" alt=""></div><div class=" VIpgJd-yAWNEb-hvhgNd-k77Iif-i3jM8c"><div class="VIpgJd-yAWNEb-hvhgNd-IuizWc" dir="ltr">Original text</div><div id="goog-gt-original-text" class="VIpgJd-yAWNEb-nVMfcd-fmcmS VIpgJd-yAWNEb-hvhgNd-axAV1"></div></div><div class="VIpgJd-yAWNEb-hvhgNd-N7Eqid ltr"><div class="VIpgJd-yAWNEb-hvhgNd-N7Eqid-B7I4Od ltr" dir="ltr"><div class="VIpgJd-yAWNEb-hvhgNd-UTujCb">Rate this translation</div><div class="VIpgJd-yAWNEb-hvhgNd-eO9mKe">Your feedback will be used to help improve Google Translate</div></div><div class="VIpgJd-yAWNEb-hvhgNd-xgov5 ltr"><button id="goog-gt-thumbUpButton" type="button" class="VIpgJd-yAWNEb-hvhgNd-bgm6sf" title="Good translation" aria-label="Good translation" aria-pressed="false"><span id="goog-gt-thumbUpIcon"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M21 7h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 0S7.08 6.85 7 7H2v13h16c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73V9c0-1.1-.9-2-2-2zM7 18H4V9h3v9zm14-7l-3 7H9V8l4.34-4.34L12 9h9v2z"></path></svg></span><span id="goog-gt-thumbUpIconFilled"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M21 7h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 0S7.08 6.85 7 7v13h11c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73V9c0-1.1-.9-2-2-2zM5 7H1v13h4V7z"></path></svg></span></button><button id="goog-gt-thumbDownButton" type="button" class="VIpgJd-yAWNEb-hvhgNd-bgm6sf" title="Poor translation" aria-label="Poor translation" aria-pressed="false"><span id="goog-gt-thumbDownIcon"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M3 17h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 24s7.09-6.85 7.17-7h5V4H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2zM17 6h3v9h-3V6zM3 13l3-7h9v10l-4.34 4.34L12 15H3v-2z"></path></svg></span><span id="goog-gt-thumbDownIconFilled"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M3 17h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 24s7.09-6.85 7.17-7V4H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2zm16 0h4V4h-4v13z"></path></svg></span></button></div></div><div id="goog-gt-votingHiddenPane" class="VIpgJd-yAWNEb-hvhgNd-aXYTce"><form id="goog-gt-votingForm" action="//translate.googleapis.com/translate_voting?client=te_lib" method="post" target="votingFrame" class="VIpgJd-yAWNEb-hvhgNd-aXYTce"><input type="text" name="sl" id="goog-gt-votingInputSrcLang"><input type="text" name="tl" id="goog-gt-votingInputTrgLang"><input type="text" name="query" id="goog-gt-votingInputSrcText"><input type="text" name="gtrans" id="goog-gt-votingInputTrgText"><input type="text" name="vote" id="goog-gt-votingInputVote"></form><iframe name="votingFrame" frameborder="0"></iframe></div></div></div><a href="#" id="toTop" style="display: none;"><span id="toTopHover"></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">To Top</font></font></a><span id="PING_IFRAME_FORM_DETECTION" style="display: none;"></span>






